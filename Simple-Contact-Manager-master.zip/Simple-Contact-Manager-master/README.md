# Simple-Contact-Manager
I made this program mainly to gain a better understanding of various programming concepts when I was first learning how to program.

**Note**: This program is considered final and therefore I most likely wont be doing any major updates.
